<?php
/**
 * Plugin Name: StatsBro
 * Plugin URI: https://statsbro.io
 * Description: A plugin to integrate StatsBro - GDPR compliant and friendly web analytics. An alternative to Google Analytics.
 * Version: 1.0
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: statsbro
 */

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Main plugin class
class StatsBro {
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function enqueue_scripts() {
        wp_enqueue_script('statsbro-custom-js', 'https://data.statsbro.io/js/script.js', [], null, false);
    }

    public function add_admin_menu() {
        add_menu_page('StatsBro', 'StatsBro', 'manage_options', 'statsbro', [$this, 'display_iframe'], 'dashicons-chart-area', 90);
		add_submenu_page('statsbro', 'StatsBro Settings', 'Settings', 'manage_options', 'statsbro-settings', [$this, 'statsbro_settings_page']);
    }

    public function display_iframe() {
        $url = esc_url(get_option('statsbro_custom_url'));
        if (empty($url)) {
            echo '<p>Please set the custom URL in the <a href="' . admin_url('admin.php?page=statsbro-settings') . '">StatsBro settings</a>.</p>';
        } else {
            echo '<iframe src="' . $url . '" style="width: 100%; height: 100%; border: none; min-height: 80vh;"></iframe>';
        }
    }

    public function register_settings() {
        register_setting('statsbro', 'statsbro_custom_url', ['type' => 'string', 'sanitize_callback' => 'esc_url_raw']);
        add_settings_section('statsbro_section', 'StatsBro Settings', null, 'statsbro');
        add_settings_field('statsbro_custom_url', 'Stats dashboard URL', [$this, 'render_url_field'], 'statsbro', 'statsbro_section');
    }

    public function render_url_field() {
        $url = esc_url(get_option('statsbro_custom_url'));
        echo '<input type="url" id="statsbro_custom_url" name="statsbro_custom_url" value="' . $url . '" class="regular-text" />';
    }
	
	// Settings page content
	public function statsbro_settings_page() {
		?>
		<div class="wrap">
			<h1>StatsBro Settings</h1>
			<form method="post" action="options.php">
				<?php settings_fields('statsbro'); ?>
				<?php do_settings_sections('statsbro'); ?>
				
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}

new StatsBro();
