=== Plugin Name ===
Contributors: statsbro
Tags: analytics,google analytics,privacy,stats,web analytics
Requires at least: 4.7
Tested up to: 6.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
A plugin to integrate StatsBro - GDPR compliant and friendly web analytics. An alternative to Google Analytics.
Find out more at: https://statsbro.io/